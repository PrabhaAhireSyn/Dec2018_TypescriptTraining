"use strict";
exports.__esModule = true;
var a_1 = require("./a");
a_1.hello();
