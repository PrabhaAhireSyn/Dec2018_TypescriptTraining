export function hello() {
  console.log("hello");
}
