import { hello } from "./a";
hello();
