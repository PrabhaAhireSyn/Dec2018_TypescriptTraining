"use strict";
exports.__esModule = true;
function hello() {
    console.log("hello");
}
exports.hello = hello;
