// 1. Explicit
let num1: number = 100;
// 2. Implicit Type Declaration
let num2 = 300;

// string is too a complex type aka object
let name1: string = "Mahesh";

// 3. Implicit Array Declaration --> implicitely accepted as array instance
let names = ["Tejas", "Mahesh", "Ramesh", "Ram", "Sabnis"];

console.log("ES 3 for loop");
for (let i = 0; i < names.length; i++) {
  console.log("Name at " + i + "position is " + names[i]);
}
console.log();

console.log("ES 5 for..in loop");
for (let i in names) {
  console.log("Name at " + i + "position is " + names[i]);
}
console.log();

console.log("ES 6 for..of loop. Uses Iterators from ES 6");
for (let i of names) {
  console.log("name is " + i);
}
console.log();
