// ... aka "spread operator", internally read as
// Object.create() --> ES 5 mechanism for deep copy
function processValues() {
    var values = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        values[_i] = arguments[_i];
    }
    // arguments = object.create(values)
    var sum = 0;
    if (values.length > 0) {
        values.forEach(function (v, i) {
            sum += v;
        });
    }
    return sum;
}
console.log("Zero Args " + processValues());
console.log("2 Args " + processValues(3, 4));
console.log("3 Args " + processValues(3, 5, 7));
console.log("" + processValues(3, 5, 7, 9));
