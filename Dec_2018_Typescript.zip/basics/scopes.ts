// scope declaration is implemented using 'let' keyword

function doWork(x: boolean) {
  let y = 0;
  if (x) {
    y = 100;
    console.log("In block " + y);
  }
  console.log("Out of block " + y);
}

doWork(true);
doWork(false);
