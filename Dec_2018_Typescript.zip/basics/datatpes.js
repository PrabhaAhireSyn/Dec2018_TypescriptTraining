// 1. Explicit
var num1 = 100;
// 2. Implicit Type Declaration
var num2 = 300;
var name1 = "Mahesh";
// 3. Implicit Array Declaration --> implicitely accepted as array instance
var names = ["Tejas", "Mahesh", "Ramesh", "Ram", "Sabnis"];
console.log("ES 3 for loop");
for (var i = 0; i < names.length; i++) {
    console.log("Name at " + i + "position is " + names[i]);
}
console.log();
console.log("ES 5 for..in loop");
for (var i in names) {
    console.log("Name at " + i + "position is " + names[i]);
}
console.log();
console.log("ES 6 for..of loop. Uses Iterators from ES 6");
for (var _i = 0, names_1 = names; _i < names_1.length; _i++) {
    var i = names_1[_i];
    console.log("name is " + i);
}
console.log();
