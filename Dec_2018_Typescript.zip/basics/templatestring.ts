let fname: string = "Mahesh";
let mname: string = "R";
let lname: string = "Sabnis";

console.log("Traditional JS Concatination");
let fullNameOld = fname + " " + mname + " " + lname;
console.log(fullNameOld);

console.log("Template String");

let fullNameTemplate = `${fname} 
                ${mname}
                ${lname}`;
console.log(fullNameTemplate);
