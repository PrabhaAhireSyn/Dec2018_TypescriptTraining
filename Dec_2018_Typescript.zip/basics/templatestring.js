var fname = "Mahesh";
var mname = "R";
var lname = "Sabnis";
console.log("Traditional JS Concatination");
var fullNameOld = fname + " " + mname + " " + lname;
console.log(fullNameOld);
console.log("Template String");
var fullNameTemplate = fname + " \n                " + mname + "\n                " + lname;
console.log(fullNameTemplate);
