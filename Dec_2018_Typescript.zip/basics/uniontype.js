// 1. Use this when the data is received
// from external sources and exact value type
// is not known while receiving, but some projected
// data types are known to us
var value;
value = 120;
value = "Ajay";
function process(val) {
    if (typeof val === "number") {
        console.log("val = " + val * val);
    }
    else {
        console.log("val = " + val.toUpperCase());
    }
}
process(100);
process("typescript");
