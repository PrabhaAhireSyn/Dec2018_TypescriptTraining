// implemented using 'let' keyword
function doWork(x) {
    var y = 0;
    if (x) {
        y = 100;
        console.log("In block " + y);
    }
    console.log("Out of block " + y);
}
doWork(true);
doWork(false);
