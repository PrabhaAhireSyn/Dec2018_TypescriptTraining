var tupleData;
tupleData = ["A", true];
console.log(tupleData[0]);
console.log(tupleData[1]);
