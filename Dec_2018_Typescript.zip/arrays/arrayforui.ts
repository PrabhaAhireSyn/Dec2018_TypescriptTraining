let data: Array<string> = new Array<string>();

function addData(item: string): Array<string> {
  data.push(item);
  return data;
}
