let dataValues: Array<string> = new Array<string>();
dataValues.push("Jason Bourn");
dataValues.push("James Bons");
dataValues.push("Indiana Jones");
dataValues.push("Ethan Hunt");
dataValues.push("Jack Reacher");

// iterate using forEach
dataValues.forEach(function(val: string, idx: number) {
  console.log(`Value at index ${idx} is ${val}`);
});
console.log();
// iterate using forEach
dataValues.forEach((val: string, idx: number) => {
  console.log(`Using Arrow Value at index ${idx} is ${val}`);
});
console.log("Sort");

dataValues.sort().forEach((val: string, idx: number) => {
  console.log(`Using Arrow Value at index ${idx} is ${val}`);
});

console.log("reverse");

dataValues.reverse().forEach((val: string, idx: number) => {
  console.log(`Using Arrow Value at index ${idx} is ${val}`);
});

let startsWithJ: Array<string> = dataValues.filter(
  (val: string, idx: number) => {
    return val.charAt(0) === "J";
  }
);
console.log("Names starts with J");
startsWithJ.forEach((v, i) => {
  console.log(v);
});
