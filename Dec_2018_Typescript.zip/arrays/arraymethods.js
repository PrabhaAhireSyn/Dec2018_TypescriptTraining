var dataValues = new Array();
dataValues.push("Jason Bourn");
dataValues.push("James Bons");
dataValues.push("Indiana Jones");
dataValues.push("Ethan Hunt");
dataValues.push("Jack Reacher");
// iterate using forEach
dataValues.forEach(function (val, idx) {
    console.log("Value at index " + idx + " is " + val);
});
console.log();
// iterate using forEach
dataValues.forEach(function (val, idx) {
    console.log("Using Arrow Value at index " + idx + " is " + val);
});
console.log("Sort");
dataValues.sort().forEach(function (val, idx) {
    console.log("Using Arrow Value at index " + idx + " is " + val);
});
console.log("reverse");
dataValues.reverse().forEach(function (val, idx) {
    console.log("Using Arrow Value at index " + idx + " is " + val);
});
var startsWithJ = dataValues.filter(function (val, idx) {
    return val.charAt(0) === "J";
});
console.log("Names starts with J");
startsWithJ.forEach(function (v, i) {
    console.log(v);
});
