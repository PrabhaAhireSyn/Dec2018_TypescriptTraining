// 1. JSON object
var Product = {
    ProdId: 0,
    ProdName: ""
};
var Products = [
    { ProdId: 1, ProdName: "P1", Manufacturers: [{ ManId: 1, MamName: "A" }] },
    { ProdId: 2, ProdName: "P2" },
    { ProdId: 3, ProdName: "P3" },
    { ProdId: 4, ProdName: "P4" }
];
Products.map(function (p, idx) {
    console.log(p.ProdId + " " + p.ProdName + " " + JSON.stringify(p.Manufacturers));
});
