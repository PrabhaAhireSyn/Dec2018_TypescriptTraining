var data = new Array();
function addData(item) {
    data.push(item);
    return data;
}
