// 1/ defining a type
type Stringify<T> = { [K in keyof T]: string };

function stringifyProps<T>(obj: T) {
  const result = {} as Stringify<T>;
  for (const prop in obj) {
    result[prop] = String(obj[prop]);
  }
  return result;
}

let res = stringifyProps({ hello: 100, world: true }); // has type `{ hello: string, world: string }`
console.log(typeof res.hello + "  " + typeof res.world);
