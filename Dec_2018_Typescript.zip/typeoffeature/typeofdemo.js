function stringifyProps(obj) {
    var result = {};
    for (var prop in obj) {
        result[prop] = String(obj[prop]);
    }
    return result;
}
var res = stringifyProps({ hello: 100, world: true }); // has type `{ hello: string, world: string }`
console.log(typeof res.hello + "  " + typeof res.world);
