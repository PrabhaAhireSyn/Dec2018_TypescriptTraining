var path = require("path"); // loading IO module
// webpack configuration
module.exports = {
  entry: "./mymodules/file2.ts", // entry files
  devtool: "inline-source-map", // use .map files
  module: {
    // the required modules for webpack
    // the webpack runtime configuration as "rules"
    rules: [
      {
        test: /\.tsx?$/,
        use: "ts-loader",
        exclude: /node_modules/
      }
    ]
  },
  resolve: {
    extensions: [".tsx", ".ts", ".js"] // extension resolvers
  },
  output: {
    filename: "bundle.js",
    path: path.resolve(__dirname, "dist")
  }
};
