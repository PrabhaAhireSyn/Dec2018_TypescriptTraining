var Person = /** @class */ (function () {
    function Person(PersonId, PersonName, Age) {
        this.PersonId = PersonId;
        this.PersonName = PersonName;
        this.Age = Age;
    }
    return Person;
}());
var PersonLogic = /** @class */ (function () {
    function PersonLogic() {
        this.person = new Person(0, "", 0);
        this.persons = new Array();
        this.persons.push(new Person(101, "A", 20));
        this.persons.push(new Person(102, "B", 30));
    }
    PersonLogic.prototype.getPerson = function () {
        return this.persons;
    };
    PersonLogic.prototype.addPerson = function (p) {
        this.persons.push(p);
        return this.persons;
    };
    return PersonLogic;
}());
// let per = new Person(0, "", 0);
// let logic = new PersonLogic();
// logic.getPerson().forEach((p, idx) => {
//   console.log(`PersonId ${p.PersonId} Name ${p.PersonName} Age ${p.Age}`);
// });
// per.PersonId = 103;
// per.PersonName = "C";
// per.Age = 40;
// logic.addPerson(per).forEach((p, idx) => {
//   console.log(`PersonId ${p.PersonId} Name ${p.PersonName} Age ${p.Age}`);
// });
