class MathClass {
  //   private x: number = 0;
  //   private y: number = 0;

  //   constructor(x: number, y: number) {
  //     this.x = x;
  //     this.y = y;
  //   }

  constructor(private x: number, private y: number) {}

  add(): number {
    return this.x + this.y;
  }
  subtract(): void {
    console.log(`Subtract ${this.x - this.y}`);
  }
}

let obj = new MathClass(20, 10);
console.log(`Add = ${obj.add()}`);
obj.subtract();
