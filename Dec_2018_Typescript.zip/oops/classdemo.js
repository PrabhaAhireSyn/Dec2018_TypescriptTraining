var MathClass = /** @class */ (function () {
    //   private x: number = 0;
    //   private y: number = 0;
    //   constructor(x: number, y: number) {
    //     this.x = x;
    //     this.y = y;
    //   }
    function MathClass(x, y) {
        this.x = x;
        this.y = y;
    }
    MathClass.prototype.add = function () {
        return this.x + this.y;
    };
    MathClass.prototype.subtract = function () {
        console.log("Subtract " + (this.x - this.y));
    };
    return MathClass;
}());
var obj = new MathClass(20, 10);
console.log("Add = " + obj.add());
obj.subtract();
