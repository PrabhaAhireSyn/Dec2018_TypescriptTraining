// export the class as Container for all its declarations
export class StringOperations {
  getLength(str: string): number {
    return str.length;
  }

  changeCase(str: string, choice: string): string {
    let resStr: string = "";
    switch (choice) {
      case "L":
        resStr = str.toLowerCase();
        break;
      case "U":
        resStr = str.toUpperCase();
        break;
    }
    return resStr;
  }
}
