// importing StringOperations
import { StringOperations } from "./file1";
let strUtility = new StringOperations();
let str: string = "TypeScript is Superb";
console.log(`Length of ${str} is = ${strUtility.getLength(str)}`);
console.log(`Lower case of ${str} is = ${strUtility.changeCase(str, "L")}`);
console.log(`Upper Case of ${str} is = ${strUtility.changeCase(str, "U")}`);
