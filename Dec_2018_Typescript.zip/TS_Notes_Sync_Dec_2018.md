Runtime: node.js --> https://www.nodejs.org
IDE: Visual Studio Code --> https://code.visualstudio.com
===========================================================================

1. The TypeScript installation
   1. Use Node Package Manager --> npm
   2. npm init -y
      1. create package.json --> Config file for F.E. Apps
      1. Contains list of dependencies for Application Development/Build/Execution
   3. npm install -g typescript
      1. Installtion of TypeScript in global scope (Machine-Level-User-Profile)
   4. npm install --save-dev TypeScript 1. For the Current Application
      2.TypeScript Transpilation (Transform After Compilation) - tsc <TypeSctipt-FileName>.ts - Generate TypeSctipt-FileName.js
      - tsc -outFile (Used to Merge multiple TypeScript files into single JavaScript File after compilation) --> Used for Modularity

===========================================================================
TypeScript is a Language that simplifies ES 6. What is ES 6?
ES 6 is a new Web Standard for Browser bases (Desktop and Devices) front-End Applications. Language Specifications for Modern Web Apps for E2E Isomorphics.
ES 6 Languages

- TypeScript
- JavaScript for ES 6 (Used in React/React-Native) --> High Level JavaScript
- # Dart

TypeScript Compilation Configuration

- Configure the current app for TS Specification for Compilation e.g. output JavaScript Specification
  - ES3/ES5
  - tsc -init
    - The tsconfig.json file

###########################################################################
ES 6 Features Implemented by TypeScript

1. Local Scoping
2. Data Types
   1. number
   2. string
   3. Array (implicit)
      1. By default an instance of Array class
         1.Iterations to Read values for Array
   4. Boolean
   5. Date
   6. Object
   7. Provides access to Object methods
   8. any
   9. generic types
   10. Data Type Extensibility
   11. UnionTypes
   12. Type Operator --> typeof()
3. Array Methods --> Explicit
   1. The Array class that have methods for array operations
      1. push(), pop(), --> Manipulation
      2. sort(), reverse(), filter(), slice() --> Array Management
      3. find(), shift(), unshift(), splice() --> Array value based operations
      4. forEach() and map() --> Iteration methods for Array
4. Set<T> and Map<T> ==> ES 6 collection objects
5. Template String
   2. A mechansim to build immutable string object instead of concatination
   3. `This is Templates ${identitier}`
   4. Parse as immutable HTML string aka a single string object
6. Rest Parameters
   1.Used when parameters to method are not fixed
   - arguments array
   - function perform(x,y,z){....}
     - arguments array object member values for x,y,z
     - function Process(...parames:[]){}
       - map parames ==> arguments array
         - if (arguments.length>0){
         - // read parameters
         - }
7. Arrow Functions
8. Object Oriented Programming (OOPs)
   5. Class
   6. Access Specifiers
   7. Constructor Parameters as Scope Members
   8. Methods / Functions
   9. Generics
   10. Methods
   11. Members
   12. Properties
   13. Inheritance
       7.Modules
9. Other JavaScript Library Integration e.g. jQuery

###########################################################################
Iterations in ES 6

- for loop --> ES 3+
- for..in loop --> Simplified syntax for for loop ES 5+
- for..of loop --> Iterator in ES 6, transpiled as "for loop" in TypeScript

#########################################################################
use http-server to define temp. Web Server for Node application
npm install -g http-server

run the command
http-server

- starts http listening on port 8080 by default and accept request for index.html

==================================================================================================================================
TS--> OOPs

- Classes - Facts with Classes in ES 6
-
- default is Public
- Make it Private/Protected explicitely
- The "function" keyword is not required for body of method
- New parser makes return type as mandatory
- The class level data members does not need "let"
- COnstructor Parameters
- - Ctor parameters are scoped to ctor function by default
- Private access specifier for ctor parameters to scope them as "private data members" of a class.
- Public access specifier for ctor parameters to scope them as "Public data members" of a class.
- Class members are accessed within class using "this" object
- ================================================================================================================================================================================

TypeScript aka ES 6 Modularity

- Modularity on Server Side - The "export" object - The "import" object

The export object can be used for - class - function - constant arrays/declarations
The import object will be read as "require()" object

- # Modularity on Front-End - File Merging - tsc -outFile <File>.js <blank space separated list of .ts files>
  =========================================================================================

webapack --> _configured_ for Application
webpack.config.js file

- loaded and read by webpack package
- npm install -g webpack / npm install --save-dev webpack
  -> webpack --> Command on NODE CLI - load webpack.config.js and execute it based on configuration(?)

webpack.config.js

- require object section
  - provide all required dependencies for build (package)
    - the (path) module , the node.js module for file i/o
    - Other dependencies
      - HTML Templates
      - Third-Party plugins
      - e.g. Hot-Loader --> webpak-dev-server
      - e.g. ES 6 using TypeScript --> ts-loader, "npm install --sav-dev ts-loader" - if ts-loader is used then tsconfig.json is mandatory, its must have "sourceMap":true

webpack config structure

1. Loading all Dependencies
2. module.export = {
   1. entry:{
   2. // Listing of all inputs with their Dependencies
   3. },
   4. output:{
      1. // Path Configuration for Output file Generation
      2. path:'./dist'
      3. fileName:'<OutputFileName>'
   5. },
   6. modules:{
   7. // configure all loaders
   8. },
   9. devtools:{\*
   10.
   11. },
   12. plugIns:{\*
   13. // Configure all plugins
   14. }
3. }
